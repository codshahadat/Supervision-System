<div class="form-group">
    <!-- Username -->
    <label class="control-label"  for="username">Member 1</label>
    <div class="controls">
      <input type="text" id="student_id1" name="student_id1" placeholder="" class="form-control">
      
    </div>
  </div>
   
  <div class="form-group">
    <!-- Username -->
    <label class="control-label"  for="username">Member 2</label>
    <div class="controls">
      <input type="text" id="student_id2" name="student_id2" placeholder="" class="form-control">
      
    </div>
  </div>

  <div class="form-group">
    <!-- Username -->
    <label class="control-label"  for="username">Member 3</label>
    <div class="controls">
      <input type="text" id="student_id3" name="student_id3" placeholder="" class="form-control">
      
    </div>
  </div>