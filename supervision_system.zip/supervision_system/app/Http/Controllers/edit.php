<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;

class edit extends Controller
{
    public function assign($role){
        if($role=='teacher'){
            $user = DB::table('users')
            ->where('role', '=', 'teacher')
                    ->get();
    }
        return view('assign', ['user'=>$user]);
    }

    public function assignstore(Request $request)
    {
            
           $supervisor_name = $request->supervisor_name;
           $id= $request->id;
                     DB::table('groups')
                      ->where('id','=',$id)
                      ->update(['supervisor_name' => $supervisor_name]);
                      return redirect()->back();
    }

/*public function showproject()
{
    return view('showproject');
}*/

public function showproject(){
    {     $id = Session::get('userid');
          $group = DB::table('groups')
          ->where('supervisor_name','=',$id)
                  ->get();
     }
      return view('showproject', ['groups'=>$group]);
  }
  public function editgroup(Request $request)
  {
    $groupid = $request->id;
    return view('editgroup',['groupid'=>$groupid]);
  }
  public function storeedit(Request $request)
  {
    $id= $request->id;
    $memberinfo = $request->memberinfo;
    $projectinfo = $request ->projectinfo ;
    $projectstage = $request ->projectstage;
    $yeardate = $request->yeardate;
    $grade= $request ->grade;
    $percentage= $request ->percentage;
    DB::table('groups')
     ->where('id','=',$id)
     ->update(['memberinfo' => $memberinfo,
               'projectinfo'=>$projectinfo,
               'projectstage' =>$projectstage,
                'yeardate'=>$yeardate,
                'grade'=>$grade,
                'percentage'=>$percentage,]);
     return redirect()->back();
  }
}
