<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;

class login extends Controller
{
    public function register(){
        return view('register');
    }

    public function registerstore(Request $request){
        $name = $request->name;
        $email = $request->email;
        $password = $request->password;
        $confirm_password = $request->password_confirm;
        $role = $request->role;

        if($password != $confirm_password){
            return redirect()->back()->with('err', 'Password Mismatch');
        }
        else {
            DB::table('users')->insert([
                'name' => $name,
                'email' => $email,
                'password' => ($password),
                'role' => $role,
                'is_verified'=> '0'

            ]);

            return redirect()->back()->with('success', 'Registration Complete. Waiting for admin approval.');
        }
    }

    public function login(){
        return view('login');
    }

    public function loginstore(Request $request){
       $email = $request->email;
       $password = $request->password;
       $user = DB::table('users')
          ->where('email', '=', $email)
          ->where('password', '=', ($password))
          ->first();
        if($user){
            if($user->is_verified==0){
                return redirect()->back()->with('err', 'Wait for admin approvel, Not Approved Yet');
            }
            else{
                
                $request->session()->put('username', $user->name);
                $request->session()->put('userrole', $user->role);
                $request->session()->put('userid', $user->id);
                return redirect('dashboard');

            }
        }

       
        
    }

    public function dashboard(){
        if(Session::has('userrole') && Session::get('userrole')=='admin'){
            return view('admin.dashboard');   
        }
        else if(Session::has('userrole') && Session::get('userrole')=='student'){
            return view('student.dashboard');   
        }
        else if(Session::has('userrole') && Session::get('userrole')=='teacher'){
            return view('teacher.dashboard');   
        }
        else {
            return redirect('home');
        }
    }

    public function studentpanel()
    {
           return view('student.dashboard');
    }

    public function teacherpanel()
    {
           return view('teacher.dashboard');
    }
    
    
    public function home()
    {
           return view('admin.home');
    }

    public function users($status){
        if($status=='all'){
            $users = DB::table('users')
                    ->get();
        }
        else if($status=='pending'){
            $users = DB::table('users')
                        ->where('is_verified', '=', 0)
                        ->get();
        }
        
        return view('users', ['users'=>$users]);
    }

    public function approve($id){
        $affected = DB::table('users')
              ->where('id', $id)
              ->update(['is_verified' => 1]);
        return redirect()->back();
    }


    public function deny($id){
        $affected = DB::table('users')
              ->where('id', $id)
              ->update(['is_verified' => 0]);
        return redirect()->back();
    }

    public function groups(){
      {
            $groups = DB::table('groups')
                    ->get();
            $advisor = DB::table('users')
            ->where('role', '=', 'teacher')
                    ->get();
       }
        
        // return view('group', ['groups'=>$groups]);
        return view('group')->with(compact('groups', 'advisor'));
    }
    
    public function user($role){
        if($role=='teacher'){
            $user = DB::table('users')
            ->where('role', '=', 'teacher')
                    ->get();
        }
        else if($role=='student'){
            $user = DB::table('users')
                        ->where('role', '=', 'student')
                        ->get();
        }
        
        return view('role', ['user'=>$user]);
    }
  

}