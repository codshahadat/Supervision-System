<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;

class group extends Controller
{
   // public function create(){
   //     return view('create');
  //  }

  

    public function groupstore(Request $request){
        $name = $request->name;
        $student_name1 = $request->student_name1;
        $student_name2 = $request->student_name2;
        $student_name3 = $request->student_name3;
       

        
            DB::table('groups')->insert([
                'name' => $name,
                'student_name1' => $student_name1,
                'student_name2' => $student_name2,
                'student_name3' => $student_name3,
               

            ]);

            return redirect('check');
        }
    
        public function check(){
            {
                  $group = DB::table('groups')
                  //->where()
                          ->get();
             }
              return view('check', ['groups'=>$group]);
          }
        
      public function create($role){
            if($role=='student'){
                $user = DB::table('users')
                ->where('role', '=', 'student')
                        ->get();
            }
            return view('create', ['user'=>$user]);
        }
}   