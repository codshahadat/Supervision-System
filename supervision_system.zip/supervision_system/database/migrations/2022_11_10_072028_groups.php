<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        {
            Schema::create('groups', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('memberinfo')->default('No data');
                $table->string('projectinfo')->default('No data');
                $table->string('projectstage')->default('No data');

                $table->string('supervisor_name')->default('No data');
                
                $table->string('student_name1');

                $table->string('student_name2');

                $table->string('student_name3');

                $table->string('yeardate')->default('No data');
                $table->string('grade')->default('No data');
                $table->string('percentage')->default('No data');
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};
