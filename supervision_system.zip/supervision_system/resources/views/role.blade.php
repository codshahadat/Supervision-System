@extends('layout.dash')
@section('abc')

    <div class="container">  
      <div class="row justify-content-end">
        <div class="col-md-10">
            <div class="card">
      <div class="card-body">
        <h2>Users</h2> 
    <table class="table table-striped">      
        <thead>
            
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
        </thead>
        <tbody>
            @foreach($user as $u)
            <tr>
                <td>{{ $u->name }}</td>
                <td>{{ $u->email }}</td>
                <td>{{ $u->role }}</td>
                <td>{{ $u->is_verified == 1 ? 'verified': 'Pending'}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
  </div>
    </div>
    </div>
@endsection