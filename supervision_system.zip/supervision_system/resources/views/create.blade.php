@extends('layout.dash2')
@section('bcd') 
 <div class="d-flex align-content-around flex-wrap">
    <div class="container">  
      <div class="row justify-content-around">
        <div class="col-md-10">
            <div class="card">
             
      <div class="card-body">
        <div class="card-header">
          <h2></h2>
        </div>
       
        <h5 class="card-title">Create Groups</h5>
      



<form class="container" action="{{ url('store-group') }}" method="POST">
    {{ csrf_field() }}
    <div id="legend">
      <legend class="Create Group"></legend>
    </div>
    <div class="form-group">
      <!-- Username -->
      <label class="control-label"  for="username">Name</label>
      <div class="controls">
        <input type="text" id="name" name="name" placeholder="" class="form-control">
        
      </div>
    </div>
 
    

    <div class="form-group col-md-4 row justify-content-start">
      <label for="role">Member 1</label>
      <select id="student_name1" name="student_name1" class="form-control">
        <option selected> Choose Member</option>
        @foreach($user as $u)
        <option>{{ $u->id}}-{{ $u->name}}</option>
        @endforeach
      </select>
      </div>

      <div class="form-group col-md-4 row justify-content-start">
        <label for="role">Member 2</label>
        <select id="student_name2" name="student_name2" class="form-control">
          <option selected> Choose Member</option>
          @foreach($user as $u)
          <option>{{ $u->id }}-{{ $u->name}}</option>
          @endforeach
        </select>
        </div>

        <div class="form-group col-md-4 row justify-content-start">
          <label for="role">Member 3</label>
          <select id="student_name3" name="student_name3" class="form-control">
            <option selected> Choose Member</option>
            @foreach($user as $u)
            <option>{{ $u->id }}-{{ $u->name}}</option>
            @endforeach
          </select>
          </div>


    <div class="form-group">
      <!-- Button -->
      <div class="controls">
        <button type="submit"  class="btn btn-success" >Create</button>
      </div>
    </div>
  </fieldset>
</form>
</div>
</div>
</div>
</div>