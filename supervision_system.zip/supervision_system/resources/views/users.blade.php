@extends('layout.dash')
@section('abc')

    <div class="container">  
      <div class="row justify-content-end">
        <div class="col-md-10">
            <div class="card">
      <div class="card-body">
        <h2>Users</h2> 
    <table class="table table-striped">      
        <thead>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Action</th>
            <th>Cancel</th>
            <th>Created at</th>
            <th>Updated at</th>
        </thead>
        <tbody>
            @foreach($users as $u)
            <tr>
                <td>{{ $u->name }}</td>
                <td>{{ $u->email }}</td>
                <td>{{ $u->role }}</td>
                <td>{{ $u->is_verified == 1 ? 'verified': 'Pending'}}</td>
                <td>
                    @if($u->is_verified == 0)
                    <a href="{{ url('approve-user/'.$u->id) }}">Approve</a>
                    @endif
                </td>

                
                <td>
                    @if($u->is_verified == 1)
                    <a href="{{ url('deny-user/'.$u->id) }}">deny</a>
                    @endif
                </td>
                <td>{{$u->created_at}}</td>
                <td>{{$u->updated_at}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
  </div>
    </div>
    </div>
@endsection