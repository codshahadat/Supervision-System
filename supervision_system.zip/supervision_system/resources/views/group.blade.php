@extends('layout.dash')
@section('abc')    
    <div class="container">  
      <div class="row justify-content-end">
        <div class="col-md-14">
            <div class="card">
      <div class="card-body">
        <h2>Groups</h2>
        <div class="d-flex align-items-end flex-column">


        </div>
      <table class="table table-striped">      
          <thead>
              <th>Name</th>
              <th>Member Information</th>
              <th>Project Information</th>
              <th>Project Stage</th>
              <th>Completed On</th>
              <th>Grade</th>
              <th>Percentage Completed</th>
              <th>Supervisor Name</th>
              <th>Member 1 Name</th>
              <th>Member 2 Name</th>
              <th>Member 3 Name</th>
              <th>Advisor</th>
              <th>Action</th>
          </thead>
          <tbody>
              @foreach($groups as $u)
              <tr>
                  <td>{{ $u->name }}</td>
                  <td>{{ $u->memberinfo }}</td>
                  <td>{{ $u->projectinfo }}</td>
                  <td>{{ $u->projectstage }}</td>
                  <td>{{ $u->yeardate }}</td>
                  <td>{{ $u->grade }}</td>
                  <td>{{ $u->percentage }}</td>
                  <td>{{ $u->supervisor_name}}</td>
                  <td>{{ $u->student_name1}}</td>
                  <td>{{ $u->student_name2}}</td>
                  <td>{{ $u->student_name3}}</td>
                  <td>
                    
<form class="" action="{{url('store-assign/'.$u->id)}}" method="POST">
    {{ csrf_field() }}
                    <select id="supervisor_name" name="supervisor_name" class="form-control">
                        <option selected> Choose Supervisor</option>
                        @foreach($advisor as $adv)
                        <option value="{{$adv->id}}">{{$adv->id}}-{{$adv->name}}</option>
                        @endforeach
                      </select>      
                    </td>
                  <td>
                    <button type="submit" class="btn btn-success" >Assign</button>
                  </td>
                </form>
                  @endforeach
              </tr>
          </tbody>
      </table>
</div>
</div>
</div>
</form>
@endsection