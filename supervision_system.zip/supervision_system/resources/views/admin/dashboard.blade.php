@extends('layout.dash')
@section('abc')
<div class="container">
        <div class="row justify-content-end">
            <div class="col-md-10">
                <div class="card">
					<div class="card-body">
        <h2>Dashboard</h2>
        <h3>Role is: {{ Session::get('userrole') }}</h3>
    </div>
    </div>
    </div>
	</div>
    </div>
  
@endsection

