@extends('layout.dash2')
@section('bcd')    
    <div class="container">  
      <div class="row justify-content-end">
        <div class="col-md-14">
            <div class="card">
      <div class="card-body">
        <h2>Groups</h2>
        <div class="d-flex align-items-end flex-column">


        </div>
      <table class="table table-striped">      
          <thead>
              <th>Name</th>
              <th>Member Information</th>
              <th>Project Information</th>
              <th>Completed On</th>
              <th>Grade       </th>
              <th>Percentage Completed</th>
              <th>Supervisor Name</th>
              <th>Member 1 info</th>
              <th>Member 2 info</th>
              <th>Member 3 info</th>
          </thead>
          <tbody>
              @foreach($groups as $u)
              <tr>
                  <td>{{ $u->name }}</td>
                  <td>{{ $u->memberinfo }}</td>
                  <td>{{ $u->projectinfo }}</td>
                  <td>{{ $u->yeardate }}</td>
                  <td>{{ $u->grade }}</td>
                  <td>{{ $u->percentage }}</td>
                  <td>{{ $u->supervisor_name}}</td>
                  <td>{{ $u->student_name1}}</td>
                  <td>{{ $u->student_name2}}</td>
                  <td>{{ $u->student_name3}}</td>
                  @endforeach
              </tr>
          </tbody>
      </table>
</div>
</div>
</div>
@endsection