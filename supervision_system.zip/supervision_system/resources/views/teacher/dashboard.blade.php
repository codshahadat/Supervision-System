@extends('layout.dash3')
@section('efg')
<div class="container">
        <div class="row justify-content-end">
            <div class="col-md-10">
                <div class="card">
					<div class="card-body">
        <h2>Dashboard</h2>
        <h2>Welcome. {{ Session::get('username') }} ,Sir</h2>
        <h3>Role is: {{ Session::get('userrole') }}</h3>
        <h3>ID is: {{ Session::get('userid') }}</h3>
    </div>
    </div>
    </div>
	</div>
    </div>
  
@endsection
