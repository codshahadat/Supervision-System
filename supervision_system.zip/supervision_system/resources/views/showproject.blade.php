@extends('layout.dash3')
@section('efg')
    <div class="container">
      <div class="row justify-content-end">
        <div class="col-md-14">
            <div class="card">
      <div class="card-body">
        <h2>Project Groups</h2>
        <div class="name-flex align-items-end flex-column">


        </div>
      <table class="table table-striped">
          <thead>
              <th>Name</th>
              <th>Member Information</th>
              <th>Project Information</th>
              <th>Project Stage</th>
              <th>Completed On</th>
              <th>Grade</th>
              <th>Percentage Completed</th>
              <th>Supervisor Name</th>
              <th>Member 1 name</th>
              <th>Member 2 name</th>
              <th>Member 3 name</th>
              <th>Action</th>
          </thead>
          <tbody>
            
              @foreach($groups as $u)
   <form class="" action="{{url('edit-group/'.$u->id)}}" method="GET">
                {{ csrf_field() }}
              <tr>
                  <td>{{ $u->name }}</td>
                  <td>{{ $u->memberinfo }}</td>
                  <td>{{ $u->projectinfo }}</td>
                  <td>{{ $u->projectstage }}</td>
                  <td>{{ $u->yeardate }}</td>
                  <td>{{ $u->grade }}</td>
                  <td>{{ $u->percentage }}</td>
                  <td>{{ $u->supervisor_name}}</td>
                  <td>{{ $u->student_name1}}</td>
                  <td>{{ $u->student_name2}}</td>
                  <td>{{ $u->student_name3}}</td>
                  <td> <button type="submit" class="btn btn-success">Edit</button></td>
                 </form> 
                 @endforeach
              </tr>
            
            </tbody>
        
      </table>
</div>
</div>
</div>
@endsection