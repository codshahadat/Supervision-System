<?php

use App\Http\Controllers\login;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\group;
use App\Http\Controllers\edit;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('login', [login::class, 'login']);
Route::post('store-login', [login::class, 'loginstore']);
Route::get('register', [login::class, 'register']);
Route::post('store-register', [login::class, 'registerstore']);
Route::get('dashboard', [login::class, 'dashboard']);
Route::get('users/{status}', [login::class, 'users']);
Route::get('approve-user/{userid}', [login::class, 'approve']);
Route::get('deny-user/{userid}', [login::class, 'deny']);
Route::get('groups', [login::class, 'groups']);
Route::get('user/{role}', [login::class, 'user']);
Route::get('home', [login::class, 'home']);
Route::get('dashboard', [login::class, 'dashboard']);
Route::get('student', [login::class, 'studentpanel']);
Route::get('teacher', [login::class, 'teacherpanel']);


//Route::get('groups', [group::class, 'groups']);
Route::get('create/{role}', [group::class, 'create']);
Route::post('store-group', [group::class, 'groupstore']);
Route::get('check', [group::class, 'check']);


Route::get('assign/{role}', [edit::class, 'assign']);
Route::post('store-assign/{id}', [edit::class, 'assignstore']);
Route::get('show-project', [edit::class, 'showproject']);
Route::get('edit-group/{id}', [edit::class, 'editgroup']);
Route::post('store-edit/{id}', [edit::class, 'storeedit']);

//Route::get('show-project', [edit::class, 'shwgrp']);




