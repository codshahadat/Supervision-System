
<?php $__env->startSection('efg'); ?>
    <div class="container">
      <div class="row justify-content-end">
        <div class="col-md-14">
            <div class="card">
      <div class="card-body">
        <h2>Project Groups</h2>
        <div class="name-flex align-items-end flex-column">


        </div>
      <table class="table table-striped">
          <thead>
              <th>Name</th>
              <th>Member Information</th>
              <th>Project Information</th>
              <th>Project Stage</th>
              <th>Completed On</th>
              <th>Grade</th>
              <th>Percentage Completed</th>
              <th>Supervisor Name</th>
              <th>Member 1 name</th>
              <th>Member 2 name</th>
              <th>Member 3 name</th>
              <th>Action</th>
          </thead>
          <tbody>
            
              <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <form class="" action="<?php echo e(url('edit-group/'.$u->id)); ?>" method="GET">
                <?php echo e(csrf_field()); ?>

              <tr>
                  <td><?php echo e($u->name); ?></td>
                  <td><?php echo e($u->memberinfo); ?></td>
                  <td><?php echo e($u->projectinfo); ?></td>
                  <td><?php echo e($u->projectstage); ?></td>
                  <td><?php echo e($u->yeardate); ?></td>
                  <td><?php echo e($u->grade); ?></td>
                  <td><?php echo e($u->percentage); ?></td>
                  <td><?php echo e($u->supervisor_name); ?></td>
                  <td><?php echo e($u->student_name1); ?></td>
                  <td><?php echo e($u->student_name2); ?></td>
                  <td><?php echo e($u->student_name3); ?></td>
                  <td> <button type="submit" class="btn btn-success">Edit</button></td>
                 </form> 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>
            
            </tbody>
        
      </table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dash3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervision_system\resources\views/showproject.blade.php ENDPATH**/ ?>