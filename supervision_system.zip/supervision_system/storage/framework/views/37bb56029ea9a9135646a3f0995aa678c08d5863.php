<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        <h2>Dashboard</h2>
        <h3>Your Role is: <?php echo e(Session::get('userrole')); ?></h3>
        <ul>
            <li><a href="<?php echo e(url('users/all')); ?>">All Users</a></li>
            <li><a href="<?php echo e(url('users/pending')); ?>">Pending Users</a></li>
        </ul>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\supervision_system\resources\views/dashboard.blade.php ENDPATH**/ ?>