
<?php $__env->startSection('bcd'); ?>
<div class="container">
        <div class="row justify-content-end">
            <div class="col-md-10">
                <div class="card">
					<div class="card-body">
        <h2>Dashboard</h2>
        <h2>Welcome, <?php echo e(Session::get('username')); ?></h2>
        <h3>Role is: <?php echo e(Session::get('userrole')); ?></h3>
    </div>
    </div>
    </div>
	</div>
    </div>
  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.dash2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervision_system\resources\views/student/dashboard.blade.php ENDPATH**/ ?>