
<?php $__env->startSection('bcd'); ?>    
    <div class="container">  
      <div class="row justify-content-end">
        <div class="col-md-14">
            <div class="card">
      <div class="card-body">
        <h2>Groups</h2>
        <div class="d-flex align-items-end flex-column">


        </div>
      <table class="table table-striped">      
          <thead>
              <th>Name</th>
              <th>Member Information</th>
              <th>Project Information</th>
              <th>Completed On</th>
              <th>Grade       </th>
              <th>Percentage Completed</th>
              <th>Supervisor Name</th>
              <th>Member 1 info</th>
              <th>Member 2 info</th>
              <th>Member 3 info</th>
          </thead>
          <tbody>
              <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($u->name); ?></td>
                  <td><?php echo e($u->memberinfo); ?></td>
                  <td><?php echo e($u->projectinfo); ?></td>
                  <td><?php echo e($u->yeardate); ?></td>
                  <td><?php echo e($u->grade); ?></td>
                  <td><?php echo e($u->percentage); ?></td>
                  <td><?php echo e($u->supervisor_name); ?></td>
                  <td><?php echo e($u->student_name1); ?></td>
                  <td><?php echo e($u->student_name2); ?></td>
                  <td><?php echo e($u->student_name3); ?></td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>
          </tbody>
      </table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dash2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervision_system\resources\views/check.blade.php ENDPATH**/ ?>