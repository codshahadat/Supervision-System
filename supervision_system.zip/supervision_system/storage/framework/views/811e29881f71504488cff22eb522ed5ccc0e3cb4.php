<!DOCTYPE html>
<html lang="en">
<head>
<title>Bootstrap Example</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Project Supervision system</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Register</a></li>
      <li><a href="#"></a></li>
      <li><a href="#"></a></li>
    </ul>
    <button class="btn btn-danger navbar-btn">Button</button>
  </div>
</nav>



<?php echo $__env->yieldContent('abc'); ?>

		<div class="bottom section-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<div class="copyright">
							<p>© <span>2018</span> <a href="#" class="transition">SD PROJECT 2022</a> All rights reserved.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\supervision_system\resources\views/layout/header.blade.php ENDPATH**/ ?>