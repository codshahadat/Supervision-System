
<?php $__env->startSection('abc'); ?> 

    <div class="container">  
      <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card"> 
      <div class="card-body">
        <div class="card-header">
          <h2></h2>
        </div>
      
<form class="container" action="" method="POST">
    <?php echo e(csrf_field()); ?>

    
    <div id="legend">
      <legend class="Create Group">Assign group</legend>
    </div>
    <div class="form-group">
      <!-- Username -->
      
      <div class="form-group col-md-4 row justify-content-start">
        <label for="role">Group</label>
        <select id="supervisor_name" name="supervisor_name" class="form-control">
          <option selected> Choose Group</option>
          <option>dummy data</option>
        </select>
    </div>
  
    <div class="form-group col-md-4 row justify-content-start">
      <label for="role">Select Supervisor</label>
      <select id="supervisor_name" name="supervisor_name" class="form-control">
        <option selected> Choose teacher</option>
          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option><?php echo e($u->id); ?>-<?php echo e($u->name); ?></option>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      </div>

    <div class="form-group">
      <!-- Button -->
      <div class="controls">
        <button type="submit"  class="btn btn-success" >Create</button>
      </div>
    </div>
  </fieldset>
</form>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervision_system\resources\views/assign.blade.php ENDPATH**/ ?>