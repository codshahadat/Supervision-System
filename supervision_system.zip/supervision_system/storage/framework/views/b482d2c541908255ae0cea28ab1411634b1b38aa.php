
<?php $__env->startSection('efg'); ?> 
 <div class="d-flex align-content-around flex-wrap">
    <div class="container">  
      <div class="row justify-content-around">
        <div class="col-md-10">
            <div class="card">
             
      <div class="card-body">
        <div class="card-header">
          <h2></h2>
        </div>
       
        <h5 class="card-title">Edit Project Groups</h5>
      

        
      <div id="legend">
        <legend class="Edit Project Groups"></legend>
      </div>
      <form class="" action="<?php echo e(url('store-edit/'.$groupid)); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
        <!-- Username -->
        <label class="control-label"  for="username">Member Information</label>
        <div class="controls">
          <input type="text" id="memberinfo" value="" name="memberinfo"  placeholder="" class="form-control" >
          
        </div>

        <div class="form-group">
        <!-- Username -->
        <label class="control-label"  for="username">Project Information</label>
        <div class="controls">
          <input type="text" id="projectinfo" value="" name="projectinfo"  placeholder="" class="form-control" >
          
        </div>

        <div class="form-group">
        <!-- Username -->
        <label class="control-label"  for="username">Completed On</label>
        <div class="controls">
          <input type="text" id="yeardate" value="" name="yeardate"  placeholder="" class="form-control" >
          
        </div>

        <div class="form-group">
        <!-- Username -->
        <label class="control-label"  for="username">Grade</label>
        <div class="controls">
          <input type="text" id="grade" value="" name="grade"  placeholder="" class="form-control" >
          
        </div>

        <div class="form-group">
        <!-- Username -->
        <label class="control-label"  for="username">Percentage Completed</label>
        <div class="controls">
          <input type="text" id="percentage" value="" name="percentage"  placeholder="" class="form-control" >
          
        </div>


        <div class="form-group col-md-4 row justify-content-start">
        <label for="role">Software Development Stages</label>
        <select id="projectstage" name="projectstage" class="form-control">
        <option selected>Choose Stage</option>
            <option value="planning">Planning</option>
            <option value="analysis">Analysis</option>
            <option value="design">Design</option>
            <option value="development">Development</option>
            <option value="testing">Testing</option>
            <option value="implementation">Implementation</option>
          
          
        </select>
        </div>
        
    </div>           
            <div class="form-group">
               <button type="submit" class="btn btn-dark">Update</button>

               <a class="btn btn-success" href="<?php echo e(url('projectgroup')); ?>">Back to Groups</a>
            </div>

        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php echo $__env->make('layout.dash3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervision_system\resources\views/editgroup.blade.php ENDPATH**/ ?>